from tkinter.constants import FIRST
import pandas as pd
from sqlalchemy import create_engine

insdtl = pd.read_csv(r"C:\Users\DELL\Desktop\Python\InstrumentDetails.csv")
print(insdtl)
posdtl = pd.read_csv(r"C:\Users\DELL\Desktop\Python\PositionDetails.csv")
print(posdtl)
engine = create_engine('mysql+mysqlconnector://root:testing123@localhost:3306/Senthil')
insdtl.to_sql('insdetails', con=engine, if_exists='replace', index=False)
posdtl.to_sql('posdetails', con=engine, if_exists='replace', index=False)
query = '''
(select a.ID as ID, b.ID as PositionID, a.ISIN as ISIN,
b.Quantity as Quantity , b.Quantity * a.UnitPrice as TotalPrice
from Senthil.insdetails as a
JOIN Senthil.posdetails as b
ON a.ID = b.ID);
'''
target=pd.read_sql_query(query, con=engine)
target.to_sql('positionreport2', con=engine, if_exists='replace', index=False)
target.to_csv(r"C:\Users\DELL\Desktop\Python\PositionResutls.csv", index=False)


