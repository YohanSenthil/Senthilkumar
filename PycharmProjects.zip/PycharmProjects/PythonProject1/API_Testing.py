from time import sleep
import requests
import unittest

class TestAPI(unittest.TestCase):

    BASE_URL = "https://reqres.in/api"

    def test_get_user_valid_id(self):
        url = f"{self.BASE_URL}/users/2"
        response = requests.get(url)
        self.assertEqual(response.status_code, 200)
        expected_data = {
            "id": 2,
            "email": "janet.weaver@reqres.in",
            "first_name": "Janet",
            "last_name": "Weaver",
            "avatar": "https://reqres.in/img/faces/2-image.jpg"
        }
        actual_data = response.json().get("data")
        self.assertDictEqual(expected_data, actual_data)

    def test_get_user_invalid_id(self):
        url = f"{self.BASE_URL}/users/9999"
        response = requests.get(url)
        self.assertEqual(response.status_code, 404)

    def test_get_user_boundary_zero(self):
        url = f"{self.BASE_URL}/users/0"
        response = requests.get(url)
        self.assertIn(response.status_code, [400, 404])

    def test_get_user_boundary_negative(self):
        url = f"{self.BASE_URL}/users/-1"
        response = requests.get(url)
        self.assertIn(response.status_code, [400, 404])

    def test_create_user_valid_data(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "name": "morpheus",
            "job": "leader"
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 201)
        actual_data = response.json()
        self.assertEqual(actual_data["name"], payload["name"])
        self.assertEqual(actual_data["job"], payload["job"])

    def test_create_user_missing_name(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "job": "leader"
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 400)

    def test_create_user_missing_job(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "name": "morpheus"
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 400)

    def test_create_user_empty_name(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "name": "",
            "job": "leader"
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 400)

    def test_create_user_with_empty_job(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "name": "morpheus",
            "job": ""
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 400)

    def test_create_user_long_name(self):
        url = f"{self.BASE_URL}/users"
        payload = {
            "name": "morpheus" * 1000,
            "job": "leader"
        }
        response = requests.post(url, json=payload)
        self.assertEqual(response.status_code, 400)

if __name__ == "__main__":
    unittest.main()
