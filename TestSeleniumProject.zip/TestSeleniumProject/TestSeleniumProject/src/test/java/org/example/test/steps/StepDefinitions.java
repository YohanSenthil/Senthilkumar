package org.example.test.steps;

import com.opencsv.exceptions.CsvValidationException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Main;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StepDefinitions {

    private int quantity;
    private double unitPrice;

    @Given("quantity for the product {int} from PositionDetails")
    public void quantity_for_the_product_from_position_details(Integer productId) throws CsvValidationException, IOException {
        // System.out.println("getQuantityForFirstProduct:"+ productId);
        quantity = Main.getPositionDetails(productId);
    }

    @When("extract the unitprice for the product {int} from InstrumentDetails")
    public void extract_the_unitprice_for_the_product_from_instrument_details(Integer productId) throws CsvValidationException, IOException {
        // System.out.println("getUnitPriceForFirstProduct:"+ productId);
        unitPrice = Main.getInstrumentDetails(productId);
    }

    @Then("compare the totalprices for the product {int}")
    public void compare_the_totalprices_for_the_product(Integer productId) throws CsvValidationException, IOException {
        // System.out.println("comparePricesForFirstProduct:"+ productId);
        double expectedPrice = Main.FetchTotalPrice(productId);
        double actualPrice = quantity * unitPrice;
        assertEquals(expectedPrice, actualPrice);
    }

}
