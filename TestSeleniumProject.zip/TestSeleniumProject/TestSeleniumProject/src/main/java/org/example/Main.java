package org.example;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class Main {

    private static String currDirectory = System.getProperty("user.dir");

    private static Object getData(String filename, Integer id) throws IOException, CsvValidationException {
        CSVReader csvReader = new CSVReader(new FileReader(currDirectory + "/src/main/"+ "/resources/"+filename+".csv"));
        String[] csvRecord;
        int recordIndex = filename.equalsIgnoreCase("PositionDetails")? 2 :
                            (filename.equalsIgnoreCase("InstrumentDetails")? 3 : 4);
        while((csvRecord = csvReader.readNext()) !=null){
            int i = 0;
            for(String csvValues : csvRecord){
                if(i == 0 && id.toString().equalsIgnoreCase(csvValues)){
                    return csvRecord[recordIndex];
                }
                i++;
            }
        }
        return 1;
    }

    public static Integer getPositionDetails(int id) throws IOException, CsvValidationException {
        Object quantityObj = getData("PositionDetails", id);
        return Integer.parseInt(quantityObj.toString());
    }

    public static Double getInstrumentDetails(int id) throws IOException, CsvValidationException {
        Object unitPriceObj = getData("InstrumentDetails", id);
        return Double.parseDouble(unitPriceObj.toString());
    }

    // Extract the actual totalPrice from the PositionResults File
    public static Double FetchTotalPrice(int id) throws CsvValidationException, IOException {
        Object totalPriceObj = getData("PositionResults", id);
        return Double.parseDouble(totalPriceObj.toString());
    }

    // Extract the quantity & unit-price for the given ID and return the product of it.
    public static Double CalculateTotalPrice(int id) throws IOException, CsvValidationException {
        int quantity = getPositionDetails(id);
        double price = getInstrumentDetails(id);
        return quantity * price;
    }

    public static String SayHello(){
        return "Hello!";
    }
}